# react-native-upi-app-detector

Detect installed UPI payment apps on Android and iOS devices

## Installation

```sh
npm install react-native-upi-app-detector
```

### Expo Configuration

If you're using Expo, you don't need to manually configure iOS or Android setups. Simply add the library as a config plugin in your `app.json` or `app.config.js`:

```json
{
  "expo": {
    "plugins": ["react-native-upi-app-detector"]
  }
}
```

This will automatically inject the necessary iOS schemes during `npx expo prebuild` or an EAS Build. Android manifest merging works out-of-the-box for Expo as well.

### iOS Configuration

To detect UPI apps on iOS, you must add the UPI app schemes to your `Info.plist` file inside the `<dict>` block. Without this, iOS will block the app from querying installed apps.

```xml
<key>LSApplicationQueriesSchemes</key>
<array>
  <string>phonepe</string>
  <string>tez</string>
  <string>paytmmp</string>
  <string>bhim</string>
  <string>credpay</string>
</array>
```

### Android Configuration

No manual configuration is required. The library automatically merges the correct `<queries>` into your app's `AndroidManifest.xml` during the Gradle build process.

## Usage

```js
import { multiply } from 'react-native-upi-app-detector';

// ...

const result = multiply(3, 7);
```

## Contributing

- [Development workflow](CONTRIBUTING.md#development-workflow)
- [Sending a pull request](CONTRIBUTING.md#sending-a-pull-request)
- [Code of conduct](CODE_OF_CONDUCT.md)

## License

MIT

---

Made with [create-react-native-library](https://github.com/callstack/react-native-builder-bob)
