const { withInfoPlist } = require('@expo/config-plugins');

const SCHEMES = ['phonepe', 'tez', 'paytmmp', 'bhim', 'credpay'];

const withUpiAppDetector = (config) => {
  return withInfoPlist(config, (expoConfig) => {
    if (!expoConfig.modResults.LSApplicationQueriesSchemes) {
      expoConfig.modResults.LSApplicationQueriesSchemes = [];
    }

    // Merge new schemes without duplicating
    SCHEMES.forEach((scheme) => {
      if (!expoConfig.modResults.LSApplicationQueriesSchemes.includes(scheme)) {
        expoConfig.modResults.LSApplicationQueriesSchemes.push(scheme);
      }
    });

    return expoConfig;
  });
};

module.exports = withUpiAppDetector;
