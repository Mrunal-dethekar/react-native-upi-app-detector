import { Platform } from 'react-native';
import UpiAppDetector from './NativeUpiAppDetector';
import type { UPIAppResult } from './types';

export const UPI_APPS = [
  {
    appName: 'PhonePe',
    androidPackage: 'com.phonepe.app',
    iosScheme: 'phonepe',
  },
  {
    appName: 'Google Pay',
    androidPackage: 'com.google.android.apps.nbu.paisa.user',
    iosScheme: 'tez',
  },
  {
    appName: 'Paytm',
    androidPackage: 'net.one97.paytm',
    iosScheme: 'paytmmp',
  },
  {
    appName: 'BHIM',
    androidPackage: 'in.org.npci.upiapp',
    iosScheme: 'bhim',
  },
  {
    appName: 'CRED',
    androidPackage: 'com.dreamplug.androidapp',
    iosScheme: 'credpay',
  },
];

export async function getUPIApps(): Promise<UPIAppResult[]> {
  const isAndroid = Platform.OS === 'android';

  const packageNames = UPI_APPS.map((app) =>
    isAndroid ? app.androidPackage : `${app.iosScheme}://`
  );

  try {
    const results = await UpiAppDetector.checkAppsInstalled(packageNames);

    return UPI_APPS.map((app) => {
      const key = isAndroid ? app.androidPackage : `${app.iosScheme}://`;
      return {
        ...app,
        isPresent: !!results[key],
      };
    });
  } catch (error) {
    console.warn('Failed to check installed apps', error);
    return UPI_APPS.map((app) => ({ ...app, isPresent: false }));
  }
}

export * from './types';
