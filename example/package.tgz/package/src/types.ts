export interface UPIAppResult {
  appName: string;
  androidPackage: string;
  iosScheme: string;
  isPresent: boolean;
}
