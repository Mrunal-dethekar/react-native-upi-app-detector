import type { UPIAppResult } from './types';
export declare const UPI_APPS: {
    appName: string;
    androidPackage: string;
    iosScheme: string;
}[];
export declare function getUPIApps(): Promise<UPIAppResult[]>;
export * from './types';
//# sourceMappingURL=index.d.ts.map