import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    checkAppsInstalled(packageNames: string[]): Promise<Record<string, boolean>>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeUpiAppDetector.d.ts.map